import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { ProductComponent } from './product/product.component';
import { ServicesComponent } from './services/services.component';

const appRoutes: Routes = [
  { path: 'Product', component: ProductComponent },
  { path: 'Inventory', component: ServicesComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    ServicesComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
